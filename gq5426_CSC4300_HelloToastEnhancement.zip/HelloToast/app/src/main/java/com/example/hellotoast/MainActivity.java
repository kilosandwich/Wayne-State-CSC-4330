package com.example.hellotoast;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
//for some reason you did not include the instructions to import the
//toast widget. Or if you did, I didn't read them, in any case future self
//this widget is VITALLY important.
import android.widget.Toast;
//Same thing for the textview widget. This might be a running theme
//however this is a valuable learning experience
//if you want something to work: make sure it is imported.
import android.widget.TextView;
import android.content.Intent;


public class MainActivity extends AppCompatActivity {

    private int mCount = 0;
    private TextView mShowCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        mShowCount = (TextView)findViewById(R.id.show_count);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void showToast(View view) {
        //Toast toast = Toast.makeText(this, R.string.toast_message,
             //   Toast.LENGTH_SHORT);
        //toast.show();

        // Launch DisplayMessageActivity and pass the count value
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        intent.putExtra("COUNT", mCount);
        startActivity(intent);
    }

    public void countUp(View view) {
        mCount++;
        if (mShowCount != null){
            mShowCount.setText(Integer.toString(mCount));
        }
    }
}