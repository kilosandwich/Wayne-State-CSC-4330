package com.example.implicitintents;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

//because the assignment doesn't tell us what to import
import android.net.Uri;
import android.content.Intent;
import android.util.Log;
import android.widget.EditText;
import androidx.core.app.ShareCompat;

import android.provider.MediaStore; //for accessing the camera
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat; //for checking for permissions and whatnot
import androidx.core.content.ContextCompat;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //everything is purple and I regret nothing.
    private EditText mWebsiteEditText;
    private EditText mLocationEditText;
    private EditText mShareTextEditText;
    private static final int REQUEST_CAMERA_PERMISSION = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        //Get the value from the ID in the view
        mWebsiteEditText = findViewById(R.id.website_edittext);
        mLocationEditText = findViewById(R.id.location_edittext);
        mShareTextEditText = findViewById(R.id.share_edittext);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void openWebsite(View view) {
        // Get the URL text from the textEdit
        String url = mWebsiteEditText.getText().toString();

        // Parse the URI and create the intent.
        //turn that string into an actual url.
        Uri webpage = Uri.parse(url);
        //open an intent that leads to the webpage we parsed
        Intent intent = new Intent(Intent.ACTION_VIEW, webpage);

        // Find an activity to hand the intent and start that activity.
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Log.d("ImplicitIntents", "Can't handle this intent!");
        }
    }

    public void openLocation(View view) {
        // Get the string indicating a location. Input is not validated; it is
        // passed to the location handler intact.
        String loc = mLocationEditText.getText().toString();

        // Parse the location and create the intent.
        //the formatting on this parser is WILD. What the heck is it.
        Uri addressUri = Uri.parse("geo:0,0?q=" + loc);
        //they pushed the button, create a new thingy make sure to pass the thing.
        Intent intent = new Intent(Intent.ACTION_VIEW, addressUri);

        // Find an activity to handle the intent, and start that activity.
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Log.d("ImplicitIntents", "Can't handle this intent!");
        }
    }

    public void shareText(View view) {
        String txt = mShareTextEditText.getText().toString();
        String mimeType = "text/plain";
        //this is a default share button thingy. Don't worry about how
        //it works, it will just ALWAYS need to be built this way. Too bad.
        ShareCompat.IntentBuilder
                .from(this)
                .setType(mimeType)
                .setChooserTitle(R.string.share_text_with)
                .setText(txt)
                .startChooser();
    }



    public void takePicture(View view) {
        //OKAY SO I GOOFED UP IN ASKING PERMISSIONS WHEN LAUNCHING THE APP IN THE MANIFEST
        //THE SOLUTION IS OBVIOUS: ASK FOR PERMISSION EVERY TIME YOU USE THE BUTTON EVER
        //Check for camera persmissions on myself if my own manifest for the camera and if its not equal to the package
        //manager is means things are not right. Just ask for permission - problem solved.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            //Package manager says no, SO ASK AGAIN UNTIL I SAY YES
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            //Everything is good, start that intent baby.
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            // Check if there's at least one activity that can handle the camera intent
            if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                //There's a camera right
                startActivity(cameraIntent);
            } else {
                //If no camera
                Toast.makeText(this, "No camera available. Sorry Boss.", Toast.LENGTH_SHORT).show();
            }

        }
    }


}